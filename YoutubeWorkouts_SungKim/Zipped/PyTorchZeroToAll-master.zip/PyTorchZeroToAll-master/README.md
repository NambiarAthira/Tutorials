[![Build Status](https://travis-ci.org/hunkim/PythonZeroToAll.svg?branch=master)](https://travis-ci.org/hunkim/PythonZeroToAll)

# PyTorchZeroToAll
Quick 3~4 day lecture materials for HKUST students.

## Video Lectures: (RNN TBA)
* [Youtube](http://bit.ly/PyTorchVideo)
* [Bilibili](https://www.bilibili.com/video/av15823922/)

## Slides
* [Lecture Slides @GoogleDrive](http://bit.ly/PyTorchZeroAll)

If you cannot access the GoogleDoc for somehow, please check out pdf files in slides. However, slides in GoogleDrive are always latest. We really appreciate your comments.

## Previous Lectures 
* cf., http://bit.ly/TF_HKUST (3 day crash course using TensorFlow)
